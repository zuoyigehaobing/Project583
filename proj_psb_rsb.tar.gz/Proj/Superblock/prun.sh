PATH2LIB=~/Proj/Superblock/build/Superblock/LLVMSB.so        # Specify your build directory in the project
PASS=-psbpass                  # Choose either -fplicm-correctness or -fplicm-performance

# Delete outputs from previous run.
rm -f default.profraw ${1}_prof ${1}_psb ${1}_rsb ${1}_no_sb *.bc ${1}.profdata *_output *.ll

# Convert source code to bitcode (IR)
clang -emit-llvm -c ${1}.c -o ${1}.bc
# Canonicalize natural loops
opt -loop-simplify ${1}.bc -o ${1}.ls.bc
# Instrument profiler
opt -pgo-instr-gen -instrprof ${1}.ls.bc -o ${1}.ls.prof.bc
# Generate binary executable with profiler embedded
clang -fprofile-instr-generate ${1}.ls.prof.bc -o ${1}_prof

# Generate profiled data
./${1}_prof > correct_output
llvm-profdata merge -o ${1}.profdata default.profraw

# Apply Superblock
opt -o ${1}.psb.bc -pgo-instr-use -pgo-test-profile-file=${1}.profdata -load ${PATH2LIB} -psbpass < ${1}.ls.bc > /dev/null
opt -o ${1}.rsb.bc -pgo-instr-use -pgo-test-profile-file=${1}.profdata -load ${PATH2LIB} -rsbpass < ${1}.ls.bc > /dev/null

# Generate binary excutable before SuperBlock formation: Unoptimzied code
clang ${1}.ls.bc -o ${1}_no_sb
# Generate binary executable after Profile SuperBlock: Optimized code
clang ${1}.psb.bc -o ${1}_psb
# Generate binary executable after Profile SuperBlock: Comparison code
clang ${1}.rsb.bc -o ${1}_rsb

# Produce output from binary to check correctness
./${1}_psb > psb_output
./${1}_rsb > rsb_output

echo -e "\n=== Correctness Check ==="
if [ "$(diff correct_output psb_output)" != "" ]; then
    echo -e ">> PSB FAIL\n"
elif [ "$(diff correct_output rsb_output)" != "" ]; then
    echo -e ">> RSB FAIL\n" 
else
    echo -e ">> PASS\n"
    # Measure performance
    echo -e "1. Performance of unoptimized code"
    time ./${1}_no_sb > /dev/null
    echo -e "\n\n"
    echo -e "2. Performance of Random Superblock code"
    time ./${1}_rsb > /dev/null
    echo -e "\n\n"
    echo -e "2. Performance of Profiled SuperBlock code"
    time ./${1}_psb > /dev/null
    echo -e "\n\n"
fi

# Cleanup
# rm -f default.profraw ${1}_prof ${1}_psb ${1}_no_sb *.bc ${1}.profdata *_output *.ll
