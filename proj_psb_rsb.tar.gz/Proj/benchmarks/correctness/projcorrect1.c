#include <stdio.h>
#include <stdbool.h>

int main(){
	int A[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
	int B[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int i, j;
	j = 0;
  bool f1 = false;
  bool f2 = false;
	for(i = 0; i < 50; i++) {
    f1 = false;
    f2 = false;
		B[i%10] = A[j%10] + i;
   
		if (i % 5 == 0) {  // 20 times [F]
      j += 2;
      if (i % 10 == 0) {
        f1 = true;
      }
    
    } else if (i % 10 == 0) { // 10 times [G]
      j = i + 4;
    
    } else {  // 70 times [A]
      j = i + 2;
    
    }
    // [B]
    j = i + 10;
    if (i % 15 != 0) {
      f1 = true;
    } else {  // [J]
      f2 = true;
      j = i / 2;
    }
    
    if (f1) {  // [C]
      f2 = true;
      j = i + 2;
    }
    
    if (f2) { // [D]
      j += 3;
    }
      
		printf("%d\n", B[i]);
	}
	return 0;
}

