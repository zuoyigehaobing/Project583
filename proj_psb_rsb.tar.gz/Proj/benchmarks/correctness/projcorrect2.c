#include <stdio.h>

int main(){
	int A[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
	int B[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int i, j;
	j = 0;
	for(i = 0; i < 20; i++) {
  		if (i % 7 == 0){
        j = i + 2; 
        for (int m = 0; m < 10; m++) {
          B[i] = A[j] * 3 * 5 + m;
          if ((i + m) % 2 == 0)
            j = i;
          else
            j = i + 1;	
          printf("%d\n", B[i%10]);
        }

  		} 
		printf("%d\n", B[i%10]);
	}
	return 0;
}
