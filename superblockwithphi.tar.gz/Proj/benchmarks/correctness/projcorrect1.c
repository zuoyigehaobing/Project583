#include <stdio.h>
#include <stdbool.h>

int help(int input) {
  return input + 4;
}

int main(){
  int i;
  int x = 4;
	for(i = 0; i < 10; i++) {
    if (x < 13) x = x + 2;
    x = help(x);
		printf("%d\n", x);
	}
  
	return 0;
}

